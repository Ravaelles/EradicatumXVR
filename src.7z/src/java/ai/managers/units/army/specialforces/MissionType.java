package ai.managers.units.army.specialforces;

public enum MissionType {

	PROTECT_MAIN_BASE

}
